/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.pi.ati.sisforms.constante;

/**
 *
 * @author JUniel
 */
public class ConstantesURL {

    public static final String URL_APLICACAO = "http://sisforms.ati.pi.gov.br";
}
