package br.gov.pi.ati.sisforms.dao.configuracao;

import br.gov.pi.ati.sisforms.modelo.configuracao.ErroSistema;
import com.xpert.persistence.dao.BaseDAO;
import javax.ejb.Local;

/**
 *
 * @author Ayslan
 */
@Local
public interface ErroSistemaDAO extends BaseDAO<ErroSistema> {
    
}
