package br.gov.pi.ati.sisforms.mb.monitoramento;

import java.io.Serializable;
import com.xpert.core.crud.AbstractBaseBean;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import br.gov.pi.ati.sisforms.bo.monitoramento.InterrupcaoPontoAcessoBO;
import br.gov.pi.ati.sisforms.modelo.cadastro.Arquivo;
import br.gov.pi.ati.sisforms.modelo.cadastro.PontoAcesso;
import br.gov.pi.ati.sisforms.modelo.enums.Conversao;
import br.gov.pi.ati.sisforms.modelo.enums.TipoDeAcesso;
import br.gov.pi.ati.sisforms.modelo.monitoramento.InterrupcaoPontoAcesso;
import br.gov.pi.ati.sisforms.modelo.vos.RelatorioInterrupcoesVO;
import br.gov.pi.ati.sisforms.util.Utils;
import com.xpert.faces.utils.FacesJasper;
import com.xpert.faces.utils.FacesMessageUtils;
import com.xpert.persistence.query.JoinBuilder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.faces.context.FacesContext;
import static org.apache.commons.io.FilenameUtils.getExtension;
import org.bouncycastle.util.encoders.Base64;
import org.hibernate.proxy.HibernateProxy;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author Juniel
 */
@ManagedBean
@ViewScoped
public class InterrupcaoPontoAcessoMB extends AbstractBaseBean<InterrupcaoPontoAcesso> implements Serializable {

    @EJB
    private InterrupcaoPontoAcessoBO interrupcaoPontoAcessoBO;

    private List<Arquivo> arquivos;

    private PontoAcesso ponto = null;

    private TipoDeAcesso tipo = null;

    private Date dataInicial = null;

    private Date dataFinal = null;

    private String numOs = null;

    private String numeroSysaid = null;

    private List<InterrupcaoPontoAcesso> interrupcoes = new ArrayList<InterrupcaoPontoAcesso>();

    public List<InterrupcaoPontoAcesso> getInterrupcoes() {
        return interrupcoes;
    }

    public void setInterrupcoes(List<InterrupcaoPontoAcesso> interrupcoes) {
        this.interrupcoes = interrupcoes;
    }

    @Override
    public InterrupcaoPontoAcessoBO getBO() {
        return interrupcaoPontoAcessoBO;
    }

    @Override
    public String getDataModelOrder() {
        return "pontoAcesso.local";
    }

    @Override
    public JoinBuilder getDataModelJoinBuilder() {
        return new JoinBuilder("ipa").leftJoinFetch("ipa.indentificacao", "pontoAcesso");
    }

    @Override
    public void init() {
        buscar();

        if (getEntity().getId() != null) {
            arquivos = getBO().getDAO().getInitialized(getEntity().getArquivos());
        } else {
            arquivos = new ArrayList<Arquivo>();
        }
    }

    @Override
    public void save() {
        getEntity().setArquivos(arquivos);
        super.save();
    }

    public StreamedContent download(Arquivo arquivo) throws IOException {

        if (arquivo instanceof HibernateProxy) {
            HibernateProxy proxy = (HibernateProxy) arquivo;
            arquivo = (Arquivo) proxy.getHibernateLazyInitializer().getImplementation();
        }

        String nomeArquivo = arquivo.getNome();
        String extensaoArquivo = arquivo.getExtensao();

        File file = File.createTempFile(nomeArquivo, extensaoArquivo);

        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(Base64.decode(arquivo.getConteudo()));
        outputStream.flush();
        outputStream.close();

        return new DefaultStreamedContent(new FileInputStream(file), extensaoArquivo, nomeArquivo);
    }

    public void upload(FileUploadEvent event) throws FileNotFoundException, IOException {
        Arquivo arquivo = new Arquivo();
        UploadedFile uploadedFile = event.getFile();
        arquivo.setNome(uploadedFile.getFileName());
        arquivo.setExtensao(getExtension(uploadedFile.getFileName()));
        String base64AsString = new String(Base64.encode(uploadedFile.getContents()));
        arquivo.setConteudo(base64AsString);
        arquivos.add(arquivo);
    }

    public void removerArquivo(Arquivo arquivo) {
        arquivos.remove(arquivo);
    }

    public List<Arquivo> getArquivos() {
        return arquivos;
    }

    public void setArquivos(List<Arquivo> arquivos) {
        this.arquivos = arquivos;
    }

    public void gerarRelatorioInterrupcoes() {
        HashMap params = new HashMap();
        String imgLogoPI = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/images/piaui_terra_querida.jpg");
        String imgLogoAti = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/images/ati.jpg");
        params.put("LOGO_PI", imgLogoPI);
        params.put("LOGO_ATI", imgLogoAti);

        params.put("DATA_ATUAL", Utils.getDataPorExtenso(new Date()));
        params.put("PERIODO", imgLogoAti);

        List<RelatorioInterrupcoesVO> relatorio = new ArrayList<RelatorioInterrupcoesVO>();

        if (interrupcoes.size() < 1) {
            FacesMessageUtils.error("Lista vazia!!");
        } else {
            for (InterrupcaoPontoAcesso lista1 : interrupcoes) {
                PontoAcesso ponto = getBO().getDAO().getInitialized(lista1.getIndentificacao());

                RelatorioInterrupcoesVO rela1 = new RelatorioInterrupcoesVO();
                rela1.setLocalObjeto(ponto);
                rela1.setLocal(ponto.getLocal().concat(" - ").concat(ponto.getTipoAcesso().getDescricao()));
                rela1.setNumDaOS(lista1.getNumeroOrdemServico());
                rela1.setObservacoes(lista1.getObservacoes());
                rela1.setTempoTotal(Utils.diferencaEntreDadas(lista1.getDataInicial(), lista1.getDataFinal(), Conversao.HORA));
                relatorio.add(rela1);
            }
        }

        FacesJasper.createJasperReport(relatorio, params,
                "/WEB-INF/report/relatorios/relatorioInterrupcoes.jasper", "Relatorio_Semanal_Interrupcoes" + ".pdf");
    }

    public void buscar() {
        interrupcoes = getBO().listar(ponto, tipo, dataInicial, dataFinal, numOs, numeroSysaid);

        ponto = null;
        tipo = null;
        dataInicial = null;
        dataFinal = null;
        numOs = null;
        numeroSysaid = null;
    }

    public BigDecimal getTempoInterrupcao(Date dataInicial, Date dataFinal) {
        return Utils.diferencaEntreDadas(dataInicial, dataFinal, Conversao.HORA);
    }
}
