package br.gov.pi.ati.sisforms.mb.padrao;

import javax.faces.bean.ManagedBean;

/**
 * Classe que retorna os valores das enums
 *
 * @author Ayslan
 */
@ManagedBean
public class EnumMB {

}