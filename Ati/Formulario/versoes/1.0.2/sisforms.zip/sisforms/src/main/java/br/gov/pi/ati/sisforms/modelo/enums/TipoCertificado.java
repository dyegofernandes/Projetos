/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.pi.ati.sisforms.modelo.enums;

/**
 *
 * @author Juniel
 */
public enum TipoCertificado {

    E_CPF_A1("E-CPF A1 (VALIDADE 01 ANO)"),
    E_CPF_A3("E-CPF A3 (VALIDADE 03 ANOS)"),
    E_CNPJ_A1("E-CNPJ A1 (VALIDADE 01 ANO)"),
    E_CNPJ_A2("E-CNPJ A3 (VALIDADE 03 ANOS)"),
    E_EQUIPAMENTO_A1("E-EQUIPAMENTO A1 (VALIDADE 01 ANO)"),
    E_APLICACAO_A1("E-APLICAÇÃO A-1 (VALIDADE 01 ANO)");

    private TipoCertificado(String descricao) {
        this.descricao = descricao;
    }
    private String descricao;

    public String getDescricao() {
        return descricao;
    }
}
