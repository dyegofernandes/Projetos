/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.pi.ati.sisforms.modelo.formulario;

import br.gov.pi.ati.sisforms.modelo.cadastro.Orgao;
import br.gov.pi.ati.sisforms.modelo.enums.AutoridadeCertificadora;
import br.gov.pi.ati.sisforms.modelo.enums.DocumentacaoCertificado;
import br.gov.pi.ati.sisforms.modelo.enums.TipoCertificado;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author Juniel
 */
@Entity
public class ControleDeCertificado implements Serializable {

    @Id
    @SequenceGenerator(name = "ControleDeCertificado", sequenceName = "controleDeCertificado_id_seq")
    @GeneratedValue(generator = "ControleDeCertificado")
    private Long id;

    @NotNull
    private String numeroSolicitacao;

    @Size(max = 20)
    private String cnpj;

    @Size(max = 20)
    private String cpfSolicitante;

    @Size(max = 255)
    private String enderecoWeb;

    @Size(max = 255)
    private String url;

    @Size(max = 255)
    private String responsavel;

    @Size(max = 255)
    private String titular;

    @ManyToOne(fetch = FetchType.LAZY)
    @NotNull
    private Orgao orgao;

    @Size(max = 255)
    private String protocoloAti;

    private AutoridadeCertificadora ac;

    private TipoCertificado tipoCertificado;

    @Temporal(TemporalType.DATE)
    private Date dataAprovacao;

    private DocumentacaoCertificado documentacao;

    private Integer armario;

    private Integer caixa;

    private Integer sequencial;

    @Temporal(TemporalType.DATE)
    private Date baixa;

    @Size(max = 255)
    private String documentoRevogacao;

    @Temporal(TemporalType.DATE)
    private Date dataRevogacao;

    @Column(columnDefinition = "Text")
    private String observacao;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeroSolicitacao() {
        return numeroSolicitacao;
    }

    public void setNumeroSolicitacao(String numeroSolicitacao) {
        this.numeroSolicitacao = numeroSolicitacao;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCpfSolicitante() {
        return cpfSolicitante;
    }

    public void setCpfSolicitante(String cpfSolicitante) {
        this.cpfSolicitante = cpfSolicitante;
    }

    public String getEnderecoWeb() {
        return enderecoWeb;
    }

    public void setEnderecoWeb(String enderecoWeb) {
        this.enderecoWeb = enderecoWeb;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public Orgao getOrgao() {
        return orgao;
    }

    public void setOrgao(Orgao orgao) {
        this.orgao = orgao;
    }

    public String getProtocoloAti() {
        return protocoloAti;
    }

    public void setProtocoloAti(String protocoloAti) {
        this.protocoloAti = protocoloAti;
    }

    public AutoridadeCertificadora getAc() {
        return ac;
    }

    public void setAc(AutoridadeCertificadora ac) {
        this.ac = ac;
    }

    public TipoCertificado getTipoCertificado() {
        return tipoCertificado;
    }

    public void setTipoCertificado(TipoCertificado tipoCertificado) {
        this.tipoCertificado = tipoCertificado;
    }

    public Date getDataAprovacao() {
        return dataAprovacao;
    }

    public void setDataAprovacao(Date dataAprovacao) {
        this.dataAprovacao = dataAprovacao;
    }

    public DocumentacaoCertificado getDocumentacao() {
        return documentacao;
    }

    public void setDocumentacao(DocumentacaoCertificado documentacao) {
        this.documentacao = documentacao;
    }

    public Integer getArmario() {
        return armario;
    }

    public void setArmario(Integer armario) {
        this.armario = armario;
    }

    public Integer getCaixa() {
        return caixa;
    }

    public void setCaixa(Integer caixa) {
        this.caixa = caixa;
    }

    public Integer getSequencial() {
        return sequencial;
    }

    public void setSequencial(Integer sequencial) {
        this.sequencial = sequencial;
    }

    public Date getBaixa() {
        return baixa;
    }

    public void setBaixa(Date baixa) {
        this.baixa = baixa;
    }

    public String getDocumentoRevogacao() {
        return documentoRevogacao;
    }

    public void setDocumentoRevogacao(String documentoRevogacao) {
        this.documentoRevogacao = documentoRevogacao;
    }

    public Date getDataRevogacao() {
        return dataRevogacao;
    }

    public void setDataRevogacao(Date dataRevogacao) {
        this.dataRevogacao = dataRevogacao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + (this.id != null ? this.id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ControleDeCertificado other = (ControleDeCertificado) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    
}
