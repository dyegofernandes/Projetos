package br.com.pagcontascarne.dao.email;

import com.xpert.persistence.dao.BaseDAO;
import br.com.pagcontascarne.modelo.email.ModeloEmail;
import javax.ejb.Local;

/**
 *
 * @author ayslan
 */
@Local
public interface ModeloEmailDAO extends BaseDAO<ModeloEmail> {
    
}
