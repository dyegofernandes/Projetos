package br.com.pagcontascarne.mb.padrao;

import javax.faces.bean.ManagedBean;

/**
 * Classe que retorna os valores das enums
 *
 * @author Ayslan
 */
@ManagedBean
public class EnumMB {

}